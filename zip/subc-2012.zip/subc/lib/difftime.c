/*
 *	NMH's Simple C Compiler, 2012
 *	difftime()
 */

#include <time.h>

int difftime(int t1, int t0) {
	return t1 - t0;
}
