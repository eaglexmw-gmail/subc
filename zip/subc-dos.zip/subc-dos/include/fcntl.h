/*
 *	NMH's Simple C Compiler, 2014
 *	fcntl.h
 */

#define O_RDONLY	0
#define O_WRONLY	1
#define O_RDWR		2
