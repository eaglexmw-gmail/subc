/*
 *	NMH's Simple C Compiler, 2012--2014
 *	8086 target description
 */

#define CPU	"8086"
#define BPW	2
