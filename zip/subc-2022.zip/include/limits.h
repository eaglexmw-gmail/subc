/*
 *	NMH's Simple C Compiler, 2012
 *	limits.h
 */

#define CHAR_BIT	8
#define CHAR_MAX	255

#define INT_MIN		-2147483648
#define INT_MAX		2147483647
