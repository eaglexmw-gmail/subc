/*
 *	NMH's Simple C Compiler, 2012
 *	time.h
 */

char	*ctime(int t);
int	difftime(int t1, int t0);
int	time(int *tp);
